<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="footer-item">
						<div class="about-us">
							<h2>Tentang Kami</h2>
							<p>Kami terinspirasi dari jual beli mobil yang menghubungkan antara penjual individu ke individu lain, kami tidak membedakan antara penjual individu dengan dealer agar dapat melakukan negosiasi dengan mudah.</p>
							
						</div>
					</div>
				</div>
				<div class="col-md-2">
					<div class="footer-item">
						<div class="what-offer">
							<h2>What We Offer ?</h2>
							<ul>
								<li><a href="#">Sewa Mobil</a></li>
								<li><a href="#">Cari mobil bekas</a></li>
								<li><a href="#">Jual mobil bekas</a></li>
								<li><a href="#">Kemudahan Bertransaksi</a></li>
								<li><a href="#">Negosiasi mudah</a></li>
							</ul>
						</div>
					</div>
				</div>
				
				<div class="col-md-2 ml-auto">
					<div class="footer-item">

					</div>
				</div>
				<div class="col-md-12">
					<div class="sub-footer">
						<p>Copyright 2021. All rights reserved by: <a href="#">Unezira Team</a></p>
					</div>
				</div>
			</div>
		</div>
	</footer>
	


</body>
</html>